USE [temp1_DB]

DROP TABLE IF EXISTS [temp1_DB].dbo.[TempSamolotCsv];
DROP TABLE IF EXISTS [temp1_DB].dbo.[TempAwaria];
DROP TABLE IF EXISTS [temp1_DB].dbo.[TempLot];
DROP TABLE IF EXISTS [temp1_DB].dbo.[TempAvgOceny];
DROP TABLE IF EXISTS [temp1_DB].dbo.[TempTrasa];
DROP TABLE IF EXISTS [temp1_DB].dbo.[TempAwaria2];
DROP TABLE IF EXISTS [temp1_DB].dbo.[TempLot2];
DROP TABLE IF EXISTS [temp1_DB].dbo.[TempAktualizujSamolotCsv];